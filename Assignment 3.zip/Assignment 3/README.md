# COMP 3612, Fall 2023
### Assessment for Lab #6 on Chapter 13

I will mark Chapter 13, Project 1 in textbook, pages 707-708. I have also provided a PDF of those pages. Exercises 6-11 in Lab13 provide step-by-step exercises for creating a data retrieval API.

I have provided the starting files here.


  
